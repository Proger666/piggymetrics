package com.piggymetrics.notification.service;

public interface NotificationService {

	void sendBackupNotifications();

	void sendRemindNotifications();
}
